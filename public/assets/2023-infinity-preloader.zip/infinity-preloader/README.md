# Infinity Preloader

A Pen created on CodePen.io. Original URL: [https://codepen.io/jkantner/pen/mdKOpbe](https://codepen.io/jkantner/pen/mdKOpbe).

A colorful infinity-shaped spinner that involves a tricky implementation of the special gradient stroke. Split the gradient in two, do likewise with the infinity shape. The shape, however, needs to be split in such a way that each stroke can emerge with one gradient end and leave at the other. Then of course, you gotta make that seamless connection for the whole animation (the rough part).